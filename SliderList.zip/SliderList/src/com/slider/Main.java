package com.slider;

import java.util.ArrayList;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

public class Main extends ListActivity
	{

		@Override
		public void onCreate(Bundle icicle)
			{
				super.onCreate(icicle);

				ArrayList list = new ArrayList();

				for (String s : AndroidPhones)
					{
						list.add(new RowModel(s));
					}

				setListAdapter(new RatingAdapter(list));

			}

		private RowModel getModel(int position)
			{
				return (RowModel) (((RatingAdapter) getListAdapter()).getItem(position));
			}

		class RatingAdapter extends ArrayAdapter
			{
				RatingAdapter(ArrayList list)
					{
						super(Main.this, R.layout.row, list);
					}

				@Override
				public View getView(int position, View convertView, ViewGroup parent)
					{
						View row = convertView;
						ViewWrapper wrapper;
						RatingBar rate;
						if (row == null)
							{
								LayoutInflater inflater = getLayoutInflater();
								row = inflater.inflate(R.layout.row, parent, false);
								wrapper = new ViewWrapper(row);
								row.setTag(wrapper);

								rate = wrapper.getRatingBar();
								RatingBar.OnRatingBarChangeListener l = new RatingBar.OnRatingBarChangeListener()
									{
										public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromTouch)
											{
												Integer myPosition = (Integer) ratingBar.getTag();
												RowModel model = getModel(myPosition);
												model.rating = rating;
												LinearLayout parent = (LinearLayout) ratingBar.getParent();
												TextView label = (TextView) parent.findViewById(R.id.label);
												label.setText(model.toString());
											}
									};
								rate.setOnRatingBarChangeListener(l);
							}
						else
							{
								wrapper = (ViewWrapper) row.getTag();
								rate = wrapper.getRatingBar();
							}

						RowModel model = getModel(position);

						wrapper.getLabel().setText(model.toString());
						rate.setTag(new Integer(position));
						rate.setRating(model.rating);
						return (row);
					}
			}

		class RowModel
			{
				String label;
				float rating = 2.0f;

				RowModel(String label)
					{
						this.label = label;
					}

				@Override
				public String toString()
					{
						if (rating >= 3.0) { return (label.toUpperCase()); }
						return (label);
					}
			}
		static final String[] AndroidPhones = new String[]{"HTC Evo 4G", "Google Nexus One", "Motorola Devour", "Motorola CLIQ", "Samsung Galaxy S", "Motorola Droid", "myTouch 3G Slide", "Droid Eris", "Motorola Backflip", "Motorola i1", "HTC Hero", "myTouch 3G Fender", "HTC Droid Incredible", "Samsung Moment", "LG Ally ",};
	}
