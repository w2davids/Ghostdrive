package com.pfizer.android.utils;

public interface AndroidViewsConfig
	{
		public static final String PARAMS = "params";

	}
