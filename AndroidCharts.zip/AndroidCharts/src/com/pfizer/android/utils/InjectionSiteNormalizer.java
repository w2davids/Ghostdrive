package com.pfizer.android.utils;

import android.util.Log;

public class InjectionSiteNormalizer
	{

		private static final String tag = "InjectionSiteNormalizer";

		public InjectionSiteNormalizer()
			{
				// TODO Auto-generated constructor stub
			}

		/**
		 * Normalize body part names due to WheelPicker width Eg. Right Abdomen ->
		 * R-Abdomen
		 */
		public static String normalizeSiteName(String site)
			{
				String bp1 = null;
				String bp2 = null;
				String bp3 = null;

				String[] strings = site.split(" - ");

				// Description-1st part
				if (strings[0].startsWith("R-"))
					{
						bp1 = "Right " + strings[0].split("-")[1];
					}
				else if (strings[0].startsWith("L-"))
					{
						bp1 = "Left " + strings[0].split("-")[1];
					}
				else
					{
						bp1 = strings[0];
					}

				// Description-3d part
				if (strings[2].startsWith("R"))
					{
						bp3 = "Right";
					}

				if (strings[2].startsWith("L"))
					{
						bp3 = "Left";
					}

				// Description-2nd part
				bp2 = strings[1];

				Log.d(tag, "getInjectionSiteId() -> " + site + " -> " + bp1 + " -> " + bp2 + " -> " + bp3);
				String value = bp1 + " " + bp2 + " " + bp3;
				return value;
			}
	}
