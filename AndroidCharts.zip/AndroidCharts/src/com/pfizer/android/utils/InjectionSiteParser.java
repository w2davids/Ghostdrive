package com.pfizer.android.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import android.util.Log;

import com.pfizer.android.model.InjectionSitePoint;

public class InjectionSiteParser
	{
		private static final String tag = "InjectionSiteParser";
		private final List<InjectionSitePoint> list;
		private DocumentBuilderFactory factory;
		private DocumentBuilder builder;

		public InjectionSiteParser()
			{
				this.list = new ArrayList<InjectionSitePoint>();
			}

		private String getNodeValue(NamedNodeMap map, String key)
			{
				String nodeValue = null;
				Node node = map.getNamedItem(key);
				if (node != null)
					{
						nodeValue = node.getNodeValue();
					}
				return nodeValue;
			}

		public List<InjectionSitePoint> getList()
			{
				return this.list;
			}

		/**
		 * Parse XML file containing body part X/Y/Description
		 * 
		 * @param inStream
		 */
		public void parse(InputStream inStream)
			{
				try
					{
						this.factory = DocumentBuilderFactory.newInstance();
						this.builder = this.factory.newDocumentBuilder();
						this.builder.isValidating();
						Document doc = this.builder.parse(inStream, null);

						doc.getDocumentElement().normalize();
						doc.getDocumentElement();

						NodeList site = doc.getElementsByTagName("site");
						final NamedNodeMap siteAtt = site.item(0).getAttributes();

						NodeList devices = doc.getElementsByTagName("point");
						final int length = devices.getLength();

						for (int i = 0; i < length; i++)
							{
								final NamedNodeMap attr = devices.item(i).getAttributes();

								final int id = Integer.parseInt(getNodeValue(attr, "id"));
								final int x = Integer.parseInt(getNodeValue(attr, "x"));
								final int y = Integer.parseInt(getNodeValue(attr, "y"));
								final int w = Integer.parseInt(getNodeValue(attr, "width"));
								final int h = Integer.parseInt(getNodeValue(attr, "height"));
								final String description = getNodeValue(attr, "description");

								// TODO: CRUD-LAYER
								// Create InjectionSitePoint containing XY-coordinates and
								// description
								InjectionSitePoint point = new InjectionSitePoint();

								point.siteId = id;
								point.x = x;
								point.y = y;
								point.width = w;
								point.height = h;
								point.description = description;
								this.list.add(point);

								String msg = "InjectionSite Point: " + point.toString();
								Log.d(tag, msg);
							}
					}
				catch (SAXException e)
					{
						e.printStackTrace();
					}
				catch (IOException e)
					{
						e.printStackTrace();
					}
				catch (ParserConfigurationException e)
					{
						e.printStackTrace();
					}
			}
	}
