package com.pfizer.android.utils;

import android.text.format.DateFormat;

public class DateUtils
	{
		private static final DateFormat dateFormat = new DateFormat();
		private static final String dateTemplateListItemFormat = "EE, d MMM yyyy hh:mm";
		private static final String dateTemplateSectionHeaderFormat = "EE, d MMM yyyy";

		public DateUtils()
			{
				// EMPTY
			}

		/**
		 * Extract into DateUtils
		 * 
		 * @param dateTime
		 * @return
		 */
		public static String convertDateToListItemFormat(long date)
			{
				return dateFormat.format(dateTemplateListItemFormat, date).toString();
			}

		/**
		 * Extract into DateUtils
		 * 
		 * @param dateTime
		 * @return
		 */
		public static String convertDateToSectionHeaderFormat(long date)
			{
				return dateFormat.format(dateTemplateSectionHeaderFormat, date).toString();
			}
	}
