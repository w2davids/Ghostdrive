package com.pfizer.android.config;

import java.util.TimerTask;

import org.kroz.activerecord.ActiveRecordException;

import android.content.Context;
import android.util.Log;

public class DatabaseInitTask extends TimerTask
	{
		private static final String tag = "DatabaseInitTask";
		private final Context _context;

		/**
		 * 
		 * @param context
		 */
		public DatabaseInitTask(Context context)
			{
				this._context = context;
			}

		@Override
		public void run()
			{
				Log.d(tag, "run()");
				try
					{
						DatabaseInit databaseInit = DatabaseInit.getInstance(_context);
						databaseInit.initDatabase();
						databaseInit.populateAllTables();
						databaseInit.close();
					}
				catch (ActiveRecordException e)
					{
						e.printStackTrace();
					}
			}

	}
