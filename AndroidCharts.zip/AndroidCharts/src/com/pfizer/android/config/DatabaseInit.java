package com.pfizer.android.config;

import java.io.InputStream;
import java.util.List;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.ActiveRecordException;
import org.kroz.activerecord.Database;
import org.kroz.activerecord.DatabaseBuilder;

import android.content.Context;
import android.util.Log;

import com.examples.charts.R;
import com.pfizer.android.model.Appointment;
import com.pfizer.android.model.DetailsItemDescription;
import com.pfizer.android.model.InjectionEntry;
import com.pfizer.android.model.InjectionSite;
import com.pfizer.android.model.InjectionSitePoint;
import com.pfizer.android.model.InjectionSiteReaction;
import com.pfizer.android.model.JournalEntry;
import com.pfizer.android.model.JournalEntryType;
import com.pfizer.android.model.Note;
import com.pfizer.android.model.Symptom;
import com.pfizer.android.model.SymptomEntry;
import com.pfizer.android.utils.InjectionSiteParser;

public class DatabaseInit
	{
		private static final String tag = "DatabaseInit";
		private static DatabaseInit uniqueInstance;

		//
		private static Context _context;
		private static Database _database;
		private static DatabaseBuilder _builder;
		private static ActiveRecordBase _conn;

		/**
		 * Private Constructor
		 */
		private DatabaseInit(Context context)
			{
				Log.d(tag, "Context passed in: " + _context);
				_context = context;
				_builder = new DatabaseBuilder(DatabaseConfig.DATABASE_NAME);
			}

		/**
		 * 
		 * @return
		 */
		public static DatabaseInit getInstance(Context context)
			{
				if (uniqueInstance == null)
					{
						uniqueInstance = new DatabaseInit(context);
					}
				return uniqueInstance;
			}

		// //////////////////////////////////////////////////////////////////////
		/**
		 * 
		 * @throws ActiveRecordException
		 */
		public void initDatabase() throws ActiveRecordException
			{

				Log.d(tag, "initDatabase() - Initializing Database: " + DatabaseConfig.DATABASE_NAME + " Version: " + DatabaseConfig.DATABASE_VERSION);

				// Add Data Model Entities to DatabaseBuilder
				Log.d(tag, "Creating Table: JournalEntry ...");
				_builder.addClass(JournalEntry.class);

				// Add Data Model Entities to DatabaseBuilder
				Log.d(tag, "Creating Table: JournalEntryType ...");
				_builder.addClass(JournalEntryType.class);

				Log.d(tag, "Creating Table: InjectionSite ...");
				_builder.addClass(InjectionSite.class);

				Log.d(tag, "Creating Table: InjectionEntry ...");
				_builder.addClass(InjectionEntry.class);

				Log.d(tag, "Creating Table: InjectionSiteReaction ...");
				_builder.addClass(InjectionSiteReaction.class);

				Log.d(tag, "Creating Table: Symptom ...");
				_builder.addClass(Symptom.class);

				Log.d(tag, "Creating Table: SymptomEntry ...");
				_builder.addClass(SymptomEntry.class);

				Log.d(tag, "Creating Table: DetailsItemDescription ...");
				_builder.addClass(DetailsItemDescription.class);

				Log.d(tag, "Creating Table: Appointment ...");
				_builder.addClass(Appointment.class);

				Log.d(tag, "Creating Table: Note ...");
				_builder.addClass(Note.class);

				// Setup the builder
				Database.setBuilder(_builder);

				Log.d(tag, "Database opened: ActiveRecordBase");
				_conn = ActiveRecordBase.open(_context, DatabaseConfig.DATABASE_NAME, DatabaseConfig.DATABASE_VERSION);

			}

		/**
		 * 
		 * @throws ActiveRecordException
		 */
		public void populateAllTables() throws ActiveRecordException
			{
				// Populate: JournaleEntryTypeTable
				populateJournalEntryTypeTable();

				// Populate: SymptomsTable
				populateSymptomsTable();

				// Populate: InjectionSiteReactionsTable
				populateInjectionSiteReactionsTable();

				// Populate: InjectionSiteTable
				populateInjectionSiteTable();

			}

		/**
		 * 
		 * @return
		 * @throws ActiveRecordException
		 */
		private boolean populateJournalEntryTypeTable() throws ActiveRecordException
			{
				Log.d(tag, "Populating JournalEntryType Table ...");
				boolean result = false;

				String[] items = _context.getResources().getStringArray(R.array.journal_entry_types_array);
				for (String item : items)
					{
						JournalEntryType ent = _conn.newEntity(JournalEntryType.class);
						ent.name = item;
						ent.save();
						Log.d(tag, String.valueOf(ent.getID()) + " :-> " + ent.toString());

						result = true;
					}

				return result;
			}

		/**
		 * 
		 * @return
		 * @throws ActiveRecordException
		 */
		private boolean populateSymptomsTable() throws ActiveRecordException
			{
				Log.d(tag, "Populating Symptoms Table ...");
				boolean result = false;

				String[] items = _context.getResources().getStringArray(R.array.symptoms_array);
				for (String item : items)
					{
						Symptom ent = _conn.newEntity(Symptom.class);
						ent.description = item;
						ent.save();
						Log.d(tag, String.valueOf(ent.getID()) + " :-> " + ent.toString());

						result = true;
					}
				return result;
			}

		/**
		 * 
		 * @return
		 * @throws ActiveRecordException
		 */
		private boolean populateInjectionSiteReactionsTable() throws ActiveRecordException
			{
				Log.d(tag, "Populating InjectionReaction Table ...");
				boolean result = false;

				String[] items = _context.getResources().getStringArray(R.array.reactions_array);
				for (String item : items)
					{
						InjectionSiteReaction ent = _conn.newEntity(InjectionSiteReaction.class);

						ent.description = item;
						ent.save();
						Log.d(tag, String.valueOf(ent.getID()) + " :-> " + ent.toString());
						result = true;
					}
				return result;
			}

		/**
		 * 
		 * @return
		 * @throws ActiveRecordException
		 */
		private boolean populateInjectionSiteTable() throws ActiveRecordException
			{
				Log.d(tag, "Populating InjectionSite Table ...");
				boolean result = false;

				InjectionSiteParser injectionSiteParser = new InjectionSiteParser();
				InputStream inputStream = _context.getResources().openRawResource(R.raw.injection_sites_body_loc);
				injectionSiteParser.parse(inputStream);
				List<InjectionSitePoint> list = injectionSiteParser.getList();

				// CRUD: REPLACE InjectionSite
				for (InjectionSitePoint point : list)
					{
						InjectionSite ent = _conn.newEntity(InjectionSite.class);

						ent.siteId = point.siteId;
						ent.description = point.description;
						ent.x = point.x;
						ent.y = point.y;
						ent.width = point.width;
						ent.height = point.height;

						ent.save();

						Log.d(tag, String.valueOf(ent.getID()) + " :-> " + ent.toString());
						result = true;
					}
				return result;
			}

		/**
		 * 
		 */
		public void close()
			{
				if (_conn != null)
					{
						_conn.close();
						Log.d(tag, "Database closed!");

					}
			}

	}
