package com.pfizer.android.config;

import org.kroz.activerecord.ActiveRecordException;

import android.content.Context;
import android.util.Log;

public class DatabaseInitThread implements Runnable
	{
		private static final String tag = "DatabaseInitThread";
		private final Context _context;
		private final Thread _thread;

		public DatabaseInitThread(Context context)
			{
				_thread = new Thread(this);
				_context = context;
			}

		@Override
		public void run()
			{
				Log.d(tag, "run()");
				try
					{
						DatabaseInit databaseInit = DatabaseInit.getInstance(_context);
						databaseInit.initDatabase();
						databaseInit.populateAllTables();
						databaseInit.close();
					}
				catch (ActiveRecordException e)
					{
						e.printStackTrace();
					}
			}

	}
