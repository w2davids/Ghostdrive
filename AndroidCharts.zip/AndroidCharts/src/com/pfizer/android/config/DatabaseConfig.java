package com.pfizer.android.config;

public interface DatabaseConfig
	{
		public static final String DATABASE_NAME = "pfizer.db";
		public static final int DATABASE_VERSION = 1;
	}
