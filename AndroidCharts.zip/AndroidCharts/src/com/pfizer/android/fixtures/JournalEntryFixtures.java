package com.pfizer.android.fixtures;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.ActiveRecordException;
import org.kroz.activerecord.Database;
import org.kroz.activerecord.DatabaseBuilder;

import android.content.Context;
import android.util.Log;

import com.examples.charts.R;
import com.pfizer.android.config.DatabaseConfig;
import com.pfizer.android.model.JournalEntry;
import com.pfizer.android.model.JournalEntryTypeIF;

public class JournalEntryFixtures
	{
		private final static String tag = "JournalEntryFixtures";
		private final int iterations;
		private Context _context = null;
		private List<JournalEntry> dataList = null;

		// Database
		private Database _database = null;
		private DatabaseBuilder _builder = null;
		private ActiveRecordBase _ARconn = null;

		public JournalEntryFixtures(Context ctx, int iterations) throws ActiveRecordException
			{
				this._context = ctx;
				this.iterations = iterations;
				this.dataList = new ArrayList<JournalEntry>();

				// setUpDatabase();
				loadData();
				// tearDownDatabase();
			}

		/**
		 * 
		 * @throws ActiveRecordException
		 */
		private void setUpDatabase() throws ActiveRecordException
			{
				Log.d(tag, "setUpDatabase()");

				// Setup the builder
				_builder = new DatabaseBuilder(DatabaseConfig.DATABASE_NAME);
				Database.setBuilder(this._builder);
				if (_database == null)
					{
						_database = Database.open(_context, DatabaseConfig.DATABASE_NAME, DatabaseConfig.DATABASE_VERSION);
					}

				Log.d(tag, "opening ActiveRecordBase");
				_ARconn = ActiveRecordBase.open(_context, DatabaseConfig.DATABASE_NAME, DatabaseConfig.DATABASE_VERSION);
			}

		/**
		 * 
		 */
		private void tearDownDatabase()
			{
				// CLOSE DATBASE CONNECTION
				if (this._ARconn != null)
					{
						Log.d(tag, "Closing connection...");
						this._ARconn.close();
					}
			}

		private int getRandom(int min, int max)
			{
				return (int) (Math.random() * (max - min + 1));
			}

		private String getSymptom()
			{
				String[] symptomsArray = _context.getResources().getStringArray(R.array.symptoms_array);
				return symptomsArray[getRandom(0, symptomsArray.length - 1)];
			}

		private String getReaction()
			{
				String[] reactionsArray = _context.getResources().getStringArray(R.array.reactions_array);
				return reactionsArray[getRandom(0, reactionsArray.length - 1)];
			}

		private String getJournalEntryType()
			{
				String[] journalEntryTypes = _context.getResources().getStringArray(R.array.journal_entry_types_array);
				return journalEntryTypes[getRandom(0, journalEntryTypes.length - 1)];
			}

		public void loadData()
			{
				for (int i = 0; i < iterations; i++)
					{
						JournalEntry journalEntry = new JournalEntry(_database);
						journalEntry.typeId = getRandom(0, 5);

						journalEntry.title = getJournalEntryType();
						journalEntry.location = "Location:" + String.valueOf(i);

						if (journalEntry.typeId == JournalEntryTypeIF.REACTION)
							{
								journalEntry.severity = getRandom(0, 100);
								journalEntry.noteText = getReaction();
							}
						else if (journalEntry.typeId == JournalEntryTypeIF.SYMPTOM)
							{
								journalEntry.severity = getRandom(0, 100);
								journalEntry.noteText = getSymptom();
							}
						else if (journalEntry.typeId == JournalEntryTypeIF.APPOINTMENT)
							{
								journalEntry.noteText = "Appointment";
							}
						else if (journalEntry.typeId == JournalEntryTypeIF.NOTE)
							{
								journalEntry.noteText = "Note";
							}
						else if (journalEntry.typeId == JournalEntryTypeIF.INJECTION)
							{
								journalEntry.noteText = "Injection";
							}

						// CHOOSE A RANDOM INJECTION SITE
						journalEntry.injectionSiteId = getRandom(1, 45);

						int theYear = getRandom(1900, 2010);
						int theMonth = getRandom(1, 12);
						int theDate = getRandom(1, 31);
						int theHour = getRandom(0, 24);
						int theMinute = getRandom(0, 60);
						int theSecond = getRandom(0, 60);
						int theNano = getRandom(0, 60);

						// Generate Random Date range
						journalEntry.dateCreated = new Timestamp(theYear, theMonth, theDate, theHour, theMinute, theSecond, theNano);
						journalEntry.dateModified = journalEntry.dateCreated;

						// DESCRIPTION
						journalEntry.description = journalEntry.noteText;

						Log.d(tag, journalEntry.toString());
						dataList.add(journalEntry);
					}
			}

		public List<JournalEntry> getFixtureData()
			{
				return dataList;
			}
	}
