package com.pfizer.android.model;

import java.sql.Timestamp;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class JournalEntry extends ActiveRecordBase
	{
		// public for AR-access
		public int typeId;

		public String noteText;
		public Timestamp dateCreated;
		public Timestamp dateModified;

		public String title;
		public String location;

		public int injectionSiteId;
		// public String symptomEntryIdList;
		// public String reactionEntryIdList;

		public String description;
		public int severity;

		public JournalEntry()
			{
				// EMPTY
			}

		public JournalEntry(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.title + ":" + this.location + ":" + this.noteText + ":" + ":" + this.injectionSiteId + ":" + this.description + ":" + this.severity + "" + this.dateCreated.toString() + ":" + this.dateModified;
			}
	}
