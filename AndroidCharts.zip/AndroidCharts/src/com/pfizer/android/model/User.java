package com.pfizer.android.model;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class User extends ActiveRecordBase
	{

		private int age;
		public String firstName;
		public String lastName;
		public String sex;
		public String address;

		// Separate?
		public String insuranceCompany;
		public String allergies;
		public String emergencyContact;
		public String bloodType;

		// Separate Symptoms
		public String symptoms;

		// Separate Reactions
		public String reactions;
		public String notes;

		public User()
			{
			}

		public User(Database db)
			{
				super(db);
			}

	}
