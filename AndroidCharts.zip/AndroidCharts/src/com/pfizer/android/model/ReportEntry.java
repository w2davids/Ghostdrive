/**
 * 
 */
package com.pfizer.android.model;

import java.sql.Timestamp;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

/**
 * @author wdavid01
 * 
 */
public class ReportEntry extends ActiveRecordBase
	{

		// PUBLIC AR FIELDS
		public Timestamp date;
		public String injectionSite;
		public String symptoms;
		public String reactions;
		public String notes;

		public ReportEntry()
			{
				// TODO Auto-generated constructor stub
			}

		public ReportEntry(Database db)
			{
				super(db);
			}

	}
