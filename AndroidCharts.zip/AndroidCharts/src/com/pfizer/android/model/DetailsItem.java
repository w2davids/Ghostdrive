package com.pfizer.android.model;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class DetailsItem extends ActiveRecordBase
	{
		// public for AR-access
		public int detailsItemDescriptionId;
		public int severity;

		public DetailsItem()
			{
				// EMPTY
			}

		public DetailsItem(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.getID() + ":" + this.detailsItemDescriptionId + ":" + this.severity;
			}
	}
