package com.pfizer.android.model;

public interface ModelEntryUtils
	{
		public final static String EMPTY_FIELD = "-";
		public final static String ENTRY_SEPARATOR = " ; ";
		public final static String KEY_VALUE_SEPARATOR = ":";
		public final static String ONE_WEEK_AGO = "1week";
		public final static String ONE_MONTH_AGO = "1month";
		public final static String ONE_2MONTHS_AGO = "2months";
	}
