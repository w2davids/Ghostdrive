package com.pfizer.android.model;

public interface JournalEntryTypeIF
	{
		public static final int APPOINTMENT = 1;
		public static final int INJECTION = 2;
		public static final int REACTION = 3;
		public static final int NOTE = 4;
		public static final int SYMPTOM = 5;
	}
