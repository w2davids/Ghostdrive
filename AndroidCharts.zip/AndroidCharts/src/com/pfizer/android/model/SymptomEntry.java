package com.pfizer.android.model;

import java.sql.Timestamp;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

import com.pfizer.android.utils.DateUtils;

public class SymptomEntry extends ActiveRecordBase
	{
		// PUBLIC ACTIVE-RECORD FIELDS WHICH ARE MAPPED
		public String description;
		public int severity;
		public String notesText;
		public Timestamp dateCreated;
		public Timestamp dateModified;

		public SymptomEntry()
			{
				// EMPTY
			}

		public SymptomEntry(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.description + " " + " - " + this.severity + " - " + this.notesText + " - " + DateUtils.convertDateToListItemFormat(this.dateCreated.getTime());
			}

	}
