package com.pfizer.android.model;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class Symptom extends ActiveRecordBase
	{
		// public for AR-access
		public String description;

		// symptoms_array
		public Symptom()
			{
				// EMPTY
			}

		public Symptom(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.description;
			}

	}
