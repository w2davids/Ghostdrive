package com.pfizer.android.model;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class InjectionSite extends ActiveRecordBase
	{
		// public for AR-access
		public int siteId;
		public int x;
		public int y;
		public int width;
		public int height;
		public String description;

		// bodyparts array
		public InjectionSite()
			{
				// EMPTY
			}

		public InjectionSite(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return "SiteID:" + this.siteId + " " + "[" + this.x + "," + this.y + "," + this.width + "," + this.height + "," + this.description + "]";
			}

	}
