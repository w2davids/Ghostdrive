package com.pfizer.android.model;

import java.sql.Timestamp;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

import com.pfizer.android.utils.DateUtils;

public class Appointment extends ActiveRecordBase
	{
		// public for AR-access
		public String title;
		public String location;
		public String notesText;
		public Timestamp dateCreated;
		public Timestamp dateModified;

		public Appointment()
			{
				// EMPTY
			}

		public Appointment(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return "Title: " + this.title + "\n" + "Location: " + this.location + "\n" + "Date: " + DateUtils.convertDateToListItemFormat(this.dateCreated.getTime()) + "\n" + "Note: " + this.notesText;
			}
	}
