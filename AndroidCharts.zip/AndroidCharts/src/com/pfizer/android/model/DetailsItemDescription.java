package com.pfizer.android.model;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class DetailsItemDescription extends ActiveRecordBase
	{
		// public for AR-access
		public int typeId; // Refers to JournalEntryType id value
		public int itemId; // Refers to DetailsItem id value
		public String description;

		public DetailsItemDescription()
			{
				// EMPTY
			}

		public DetailsItemDescription(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.getID() + " : " + this.typeId + ":" + this.itemId + ":" + this.description;
			}
	}
