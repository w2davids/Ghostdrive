package com.pfizer.android.model;

public class InjectionSitePoint
	{
		// public for AR-access
		public int siteId;
		public int x;
		public int y;
		public int width;
		public int height;
		public String description;

		public InjectionSitePoint()
			{
				// EMPTY
			}

		@Override
		public String toString()
			{
				return this.siteId + "[" + this.x + "," + this.y + "," + this.width + "," + this.height + "," + this.description + "]";
			}
	}
