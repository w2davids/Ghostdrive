package com.pfizer.android.model;

public class SeverityRowModel
	{
		private int id;
		private String label;
		private int severity;

		public SeverityRowModel()
			{
				// EMPTY;
			}

		public SeverityRowModel(String label, int severity)
			{
				this.label = label;
				this.severity = severity;
			}

		public void setLabel(String label)
			{
				this.label = label;
			}

		public String getLabel()
			{
				return this.label;
			}

		public void setSeverity(int severity)
			{
				this.severity = severity;
			}

		public int getSeverity()
			{
				return severity;
			}

		@Override
		public String toString()
			{
				return this.label;
			}

		public void setId(int id)
	    {
			    this.id = id;
	    }

		public int getId()
	    {
			    return id;
	    }
	}