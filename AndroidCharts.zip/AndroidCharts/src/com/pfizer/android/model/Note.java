package com.pfizer.android.model;

import java.sql.Timestamp;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class Note extends ActiveRecordBase
	{
		// public for AR-access
		public String notesText;
		public Timestamp dateCreated;
		public Timestamp dateModified;

		public Note()
			{
				// EMPTY
			}

		public Note(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.getID() + ":" + this.notesText + ":" + this.dateCreated + ":" + this.dateModified;
			}
	}
