package com.pfizer.android.model;

import java.sql.Timestamp;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class InjectionEntry extends ActiveRecordBase
	{
		// public for AR-access
		public int injectionSiteId;
		public String notesText;
		public Timestamp dateCreated;
		public Timestamp dateModified;

		public InjectionEntry()
			{
				// EMPTY
			}

		public InjectionEntry(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.injectionSiteId + ":" + this.notesText + ":" + this.dateCreated;
			}
	}
