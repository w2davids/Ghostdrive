package com.pfizer.android.model;

import org.kroz.activerecord.ActiveRecordBase;
import org.kroz.activerecord.Database;

public class JournalEntryType extends ActiveRecordBase
	{
		// public for AR-access
		public String name;

		// journal_entry_types_array
		public JournalEntryType()
			{
				// EMPTY
			}

		public JournalEntryType(Database db)
			{
				super(db);
			}

		@Override
		public String toString()
			{
				return this.name;
			}

	}
