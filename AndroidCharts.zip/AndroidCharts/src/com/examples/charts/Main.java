package com.examples.charts;

import java.util.List;

import net.droidsolutions.droidcharts.core.data.XYDataset;
import net.droidsolutions.droidcharts.core.data.xy.XYSeries;
import net.droidsolutions.droidcharts.core.data.xy.XYSeriesCollection;

import org.kroz.activerecord.ActiveRecordException;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;

import com.pfizer.android.fixtures.JournalEntryFixtures;
import com.pfizer.android.model.JournalEntry;
import com.pfizer.android.model.JournalEntryTypeIF;
import com.pfizer.android.utils.DateUtils;

public class Main extends Activity
	{
		private static final String tag = "Main";
		private List<JournalEntry> fixtureData;
		private static final int n_iterations = 1000;

		/** Called when the activity is first created. */
		@Override
		public void onCreate(Bundle savedInstanceState)
			{
				Log.d(tag, "Creating View");
				super.onCreate(savedInstanceState);

				// DataSet Description
				ContentValues datasetDescription = new ContentValues();
				datasetDescription.put("chart_title", "Line Chart Demo 6");
				datasetDescription.put("x_axis", "X");
				datasetDescription.put("y_axis", "Y");
				datasetDescription.put("include_legend", true);
				datasetDescription.put("include_tooltips", true);
				datasetDescription.put("include_urls", false);

				try
					{
						JournalEntryFixtures journalEntryFixtures = new JournalEntryFixtures(this, n_iterations);
						fixtureData = journalEntryFixtures.getFixtureData();

						// Create the XY-Line Chart passing the parameters
						XYLineChartView mView = new XYLineChartView(this, datasetDescription, createDataset(fixtureData));

						// Set the View Layer
						setContentView(mView);
					}
				catch (ActiveRecordException e)
					{
						e.printStackTrace();
					}
			}

		/**
		 * Creates a sample dataset.
		 * 
		 * @return a sample dataset.
		 */
		private XYDataset createDataset(List<JournalEntry> fixtureData)
			{
				final XYSeriesCollection dataset = new XYSeriesCollection();
				final XYSeries series1 = new XYSeries("Symptoms");

				DateFormat dateFormat = new DateFormat();
				String template = "EE, d MMM yyyy hh:mm";

				int counter = 0;
				for (JournalEntry ent : fixtureData)
					{
						if (ent.typeId == JournalEntryTypeIF.SYMPTOM)
							{
								Log.d(tag, String.valueOf(counter) + ". " + ent.dateCreated + " , " + ent.severity);
								Log.d(tag, DateUtils.convertDateToListItemFormat(ent.dateCreated.getTime()));
								Log.d(tag, DateUtils.convertDateToSectionHeaderFormat(ent.dateCreated.getTime()));

								series1.add(new Double(counter), new Double(ent.severity));
								counter++;
							}
					}

				dataset.addSeries(series1);
				return dataset;
			}

		@Override
		public void onDestroy()
			{
				Log.d(tag, "Destroying View!");
				super.onDestroy();
			}
	}