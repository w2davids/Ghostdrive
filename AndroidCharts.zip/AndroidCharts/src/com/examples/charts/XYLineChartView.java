package com.examples.charts;

import net.droidsolutions.droidcharts.awt.Rectangle2D;
import net.droidsolutions.droidcharts.core.ChartFactory;
import net.droidsolutions.droidcharts.core.JFreeChart;
import net.droidsolutions.droidcharts.core.axis.NumberAxis;
import net.droidsolutions.droidcharts.core.data.XYDataset;
import net.droidsolutions.droidcharts.core.plot.PlotOrientation;
import net.droidsolutions.droidcharts.core.plot.XYPlot;
import net.droidsolutions.droidcharts.core.renderer.xy.XYLineAndShapeRenderer;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.view.View;

public class XYLineChartView extends View
	{
		private final ContentValues datasetDescription;
		private XYDataset dataset;

		/** The view bounds. */
		private final Rect mRect = new Rect();

		/** The user interface thread handler. */
		private final Handler mHandler;

		/**
		 * Creates a new graphical view.
		 * 
		 * @param context
		 *          the context
		 * @param chart
		 *          the chart to be drawn
		 */
		public XYLineChartView(Context context, ContentValues datasetDescription, XYDataset dataset)
			{
				super(context);
				mHandler = new Handler();
				this.datasetDescription = datasetDescription;
				this.setDataset(dataset);
			}

		@Override
		protected void onDraw(Canvas canvas)
			{
				super.onDraw(canvas);
				canvas.getClipBounds(mRect);

				final JFreeChart chart = createChart(getDataset());
				chart.draw(canvas, new Rectangle2D.Double(0, 0, mRect.width(), mRect.height()));
				Paint p = new Paint();
				p.setColor(Color.RED);
			}

		/**
		 * Schedule a user interface repaint.
		 */
		public void repaint()
			{
				mHandler.post(new Runnable()
					{
						public void run()
							{
								invalidate();
							}
					});
			}

		/**
		 * Creates a chart.
		 * 
		 * @param dataset
		 *          the data for the chart.
		 * 
		 * @return a chart.
		 */
		private JFreeChart createChart(final XYDataset dataset)
			{
				String chartTitle = datasetDescription.getAsString("chart_title");
				String XAxisLabel = datasetDescription.getAsString("x_axis");
				String YAxisLabel = datasetDescription.getAsString("y_axis");
				boolean includeLegend = datasetDescription.getAsBoolean("include_legend");
				boolean includeToolTips = datasetDescription.getAsBoolean("include_tooltips");
				boolean includeURLs = datasetDescription.getAsBoolean("include_urls");

				final JFreeChart chart = ChartFactory.createXYLineChart(chartTitle, XAxisLabel, YAxisLabel, dataset, PlotOrientation.VERTICAL, includeLegend, includeToolTips, includeURLs);

				Paint black = new Paint(Paint.ANTI_ALIAS_FLAG);
				black.setColor(Color.BLACK);

				Paint dkGray = new Paint(Paint.ANTI_ALIAS_FLAG);
				dkGray.setColor(Color.DKGRAY);

				Paint lightGray = new Paint(Paint.ANTI_ALIAS_FLAG);
				lightGray.setColor(Color.LTGRAY);
				lightGray.setStrokeWidth(10);

				chart.setBackgroundPaint(black);

				final XYPlot plot = chart.getXYPlot();
				plot.setBackgroundPaint(dkGray);
				plot.setDomainGridlinePaint(lightGray);
				plot.setRangeGridlinePaint(lightGray);

				final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
				renderer.setSeriesLinesVisible(0, true);
				plot.setRenderer(renderer);

				// change the auto tick unit selection to integer units only...
				final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
				rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
				// final NumberAxis domainAxis = (NumberAxis) plot.getDomainAxis();
				// domainAxis.set(CategoryLabelPositions.STANDARD);

				return chart;

			}

		public XYDataset getDataset()
			{
				return dataset;
			}

		public void setDataset(XYDataset dataset)
			{
				this.dataset = dataset;
			}

	}
