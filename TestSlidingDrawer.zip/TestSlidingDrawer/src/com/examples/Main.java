package com.examples;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SlidingDrawer;
import android.widget.Toast;
import android.widget.SlidingDrawer.OnDrawerCloseListener;
import android.widget.SlidingDrawer.OnDrawerOpenListener;

public class Main extends Activity {
	private Button buttonSlidingHandle;
	private ImageView imgSlidingHandle;
	private SlidingDrawer slidingDrawer;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		imgSlidingHandle = (ImageView) this.findViewById(R.id.handle);
		imgSlidingHandle.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Toast.makeText(getApplicationContext(), "DRAWER",
						Toast.LENGTH_SHORT).show();
			}
		});

		slidingDrawer = (SlidingDrawer) this.findViewById(R.id.drawer);

		// Sliding Drawer
		// Opening Handler
		slidingDrawer.setOnDrawerOpenListener(new OnDrawerOpenListener() {
			@Override
			public void onDrawerOpened() {
				// TODO Auto-generated method stub
			}
		});

		// Closing Handler
		slidingDrawer.setOnDrawerCloseListener(new OnDrawerCloseListener() {
			@Override
			public void onDrawerClosed() {
				// TODO Auto-generated method stub
			}
		});
	}
}