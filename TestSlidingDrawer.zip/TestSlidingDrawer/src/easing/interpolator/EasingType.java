package easing.interpolator;

public class EasingType {
	public enum Type {
		IN, OUT, INOUT
	}
}
