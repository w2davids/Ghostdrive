package com.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;

public class Main extends ListActivity
	{
		private static String[] items = {"lorem", "ipsum", "dolor", "sit", "amet", "consectetuer", "adipiscing", "elit", "morbi", "vel", "ligula", "vitae", "arcu", "aliquet", "mollis", "etiam", "vel", "erat", "placerat", "ante", "porttitor", "sodales", "pellentesque", "augue", "purus"};

		@Override
		public void onCreate(Bundle icicle)
			{
				super.onCreate(icicle);
				setContentView(R.layout.main);

				MergeAdapter adapter = new MergeAdapter();

				adapter.addAdapter(buildFirstList());
				adapter.addView(buildButton());
				adapter.addAdapter(buildSecondList());

				setListAdapter(adapter);
			}

		private ListAdapter buildFirstList()
			{
				return (new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items));
			}

		private View buildButton()
			{
				Button result = new Button(this);

				result.setText("Hello, world!");

				return (result);
			}

		private ListAdapter buildSecondList()
			{
				ArrayList<String> list = new ArrayList<String>(Arrays.asList(items));

				Collections.shuffle(list);

				return (new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list));
			}
	}